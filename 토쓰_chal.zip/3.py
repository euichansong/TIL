# 실패한 풀이
""""""
def solution(amountText):
    answer = True
    at = len(amountText)
    canlist = ['1','2','3','4','5','6','7','8','9','0',',']
    numlist = ['1','2','3','4','5','6','7','8','9','0']
    for i in range(at-1,-1,-1):
        if answer == False:
            break
        if amountText[i] not in canlist:
            answer = False
            break
        if i == 0:
            if amountText[i] == ',' or (at != 1 and amountText[i] == '0'):
                answer = False
                break
        if amountText[i] == ',':
            use = True
            # 쉼표 오른쪽에 숫자가 세 개 있는지 확인
            if i+3 >= at or not all(amountText[i+1+j] in numlist for j in range(3)):
                answer = False
                break
            if use and int(amountText(at-i-1)) % 4 == 0:
                pass



    return answer