"""
상위 25% 문제중 가장 쉬운문제
[1,2,3,4,5,6,7,8,9] 에서 8 뽑기
"""
def solution(levels):
    a = len(levels)
    # print(a)
    need_idx = a - (a // 4)
    # print(need_idx)
    levels.sort()
    b = levels[need_idx:a]
    # print(b)
    answer = 0
    if b:
        answer = min(b)
    else:
        answer = -1

    # answer =
    return answer