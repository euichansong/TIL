"""
숫자로 이루어진 문자열 s (12223)
길이가 3인 s의 서브스트링 찾기  위의 경우 222
111222999면 999 반환

"""
def solution(s):
    answer = 0
    maxnum = []
    s = list(s)
    ss = len(s)
    for i in range(1, ss - 1):
        if s[i - 1] == s[i] and s[i] == s[i + 1]:
            maxnum.append(int(s[i]))
    if maxnum:
        a = max(maxnum)
        if a == 0:
            answer = 000
        else:
            answer = a * 111
    else:
        answer = -1

    return answer